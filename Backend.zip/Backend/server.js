const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const studentRoutes = require("./routes/studentRoutes");

const app = express();
app.use(bodyParser.json());

// MongoDB connection
mongoose.connect("mongodb+srv://Studentdb:123@studentdb.ljdcgxw.mongodb.net/?retryWrites=true&w=majority&appName=Studentdb", {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log("MongoDB Connected"))
  .catch(err => console.error(err));

// Routes
app.use("/students", studentRoutes);

// Start server
const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
