const Joi = require("joi");

const studentSchema = Joi.object({
    name: Joi.string().min(2).required(),
    age: Joi.number().integer().min(1).required(),
    course: Joi.string().required()
});

module.exports = { studentSchema };
